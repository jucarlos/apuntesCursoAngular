import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { BodyComponent } from './components/body/body.component';
import { FooterComponent } from './components/footer/footer.component';
import { CitasComponent } from './components/citas/citas.component';
import { APPROUTING } from './app.routes';
import { CitaComponent } from './components/citas/cita.component';
import { MostrarCitasComponent } from './components/citas/mostrar-citas.component';
import { CitaTarjetaComponent } from './components/cita-tarjeta/cita-tarjeta.component';
import { PipesComponent } from './components/pipes/pipes.component';

import { LOCALE_ID } from '@angular/core';

import localeEs from '@angular/common/locales/es';
import { registerLocaleData } from '@angular/common';
import { AlrevesPipe } from './pipes/alreves.pipe';
import { FormularioHtmlComponent } from './components/formularios/formulario-html.component';
import { FormularioCodigoComponent } from './components/formularios/formulario-codigo.component';


registerLocaleData( localeEs );


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    BodyComponent,
    FooterComponent,
    CitasComponent,
    CitaComponent,
    MostrarCitasComponent,
    CitaTarjetaComponent,
    PipesComponent,
    AlrevesPipe,
    FormularioHtmlComponent,
    FormularioCodigoComponent
  ],
  imports: [
    BrowserModule,
    APPROUTING,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'es' }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
