import { RouterModule, Routes } from '@angular/router';
import { BodyComponent } from './components/body/body.component';
import { CitasComponent } from './components/citas/citas.component';
import { CitaComponent } from './components/citas/cita.component';
import { MostrarCitasComponent } from './components/citas/mostrar-citas.component';
import { PipesComponent } from './components/pipes/pipes.component';
import { FormularioHtmlComponent } from './components/formularios/formulario-html.component';
import { FormularioCodigoComponent } from './components/formularios/formulario-codigo.component';

const APP_ROUTES: Routes = [
    { path: 'body', component: BodyComponent },
    { path: 'citas', component: CitasComponent },
    { path: 'cita/:id', component: CitaComponent },
    { path: 'mostrar/:termino', component: MostrarCitasComponent },
    { path: 'pipes', component: PipesComponent },
    { path: 'formuhtml', component: FormularioHtmlComponent },
    { path: 'formucodigo', component: FormularioCodigoComponent },
    { path: '**', pathMatch: 'full', redirectTo: 'body' }
];

export const APPROUTING = RouterModule.forRoot(APP_ROUTES);
