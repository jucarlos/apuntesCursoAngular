import { Cita } from 'src/app/models/cita';

export const CITAS: Cita[] = [
    {
      id: 1,
      autor: 'Aristóteles',
      frase: 'Lo que con mucho trabajo se adquiere, más se ama.' ,
      img: 'assets/img/aristoteles.jpg'},
    {
      id: 2, autor: 'Platón',
      frase: 'Hay que tener el valor de decir la verdad, sobre todo cuando se habla de la verdad.' ,
      img: 'assets/img/platon.jpg'
    },
    {
      id: 3, autor: 'Einstein',
      frase: 'Dar ejemplo no es la principal manera de influir sobre los demás; es la única manera.',
      img: 'assets/img/einstein.jpg'
    },
  ];
