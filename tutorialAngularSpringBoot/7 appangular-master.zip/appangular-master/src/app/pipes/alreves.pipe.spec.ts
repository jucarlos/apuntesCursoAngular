import { AlrevesPipe } from './alreves.pipe';

describe('AlrevesPipe', () => {
  it('create an instance', () => {
    const pipe = new AlrevesPipe();
    expect(pipe).toBeTruthy();
  });
});
