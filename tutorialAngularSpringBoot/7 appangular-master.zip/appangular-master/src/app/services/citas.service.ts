import { Injectable } from '@angular/core';
import { CITAS } from '../components/citas/citas.json';
import { Cita } from '../models/cita.js';

@Injectable({
  providedIn: 'root'
})
export class CitasService {

  citas: Cita[];

  constructor() {
    console.log('Entrando en el servicio');
    this.citas = this.getCitas();
   }

  getCitas(): Cita[] {
    return CITAS;
  }

  getCita( i: number ): Cita {

    console.log(this.citas);
    const respondCitas = this.citas.filter( c => {
        return c.id === Number(i);
        } );

    return respondCitas[0];

  }

  buscarCitas( termino: string ): Cita[] {

    const citasEncontradas: Cita[] = [];

    termino = termino.toLowerCase();

    // Pasamos por todas las citas usando un for.
    for ( const cita of this.citas ) {
        const frase = cita.frase.toLowerCase();
        if ( frase.indexOf( termino ) >= 0) {
          citasEncontradas.push ( cita );
        }
    }

    return citasEncontradas;

  }

}
