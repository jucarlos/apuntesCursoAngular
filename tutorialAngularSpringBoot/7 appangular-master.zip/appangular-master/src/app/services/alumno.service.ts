import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Alumno } from '../components/alumnos/alumno';

@Injectable({
  providedIn: 'root'
})
export class AlumnoService {

  private urlEndPoint = 'http://localhost:8080/api/alumnos';

  private httpHeaders = new HttpHeaders({'Content-Type': 'application/json'});


  constructor(private http: HttpClient) { }

  getAlumnos() {
    return this.http.get( this.urlEndPoint);
  }

  creaAlumno( alumno: Alumno ) {
    return this.http.post(this.urlEndPoint, alumno, { headers: this.httpHeaders});
  }

  getAlumno ( id: number ) {
    return this.http.get( `${this.urlEndPoint}/${id}`);
  }

  updateAlumno( alumno: Alumno ) {
    return this.http.put(`${this.urlEndPoint}/${alumno.id}`, alumno, {headers: this.httpHeaders});
  }

  deleteAlumno ( id: number ) {
    return this.http.delete ( `${this.urlEndPoint}/${id}`);
  }

}
