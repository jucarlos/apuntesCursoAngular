import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-formulario-html',
  templateUrl: './formulario-html.component.html',
  styles: []
})
export class FormularioHtmlComponent {


  alumno = {
    nombre: 'Angelina',
    apellidos: 'Jolie',
    email: 'angelina@gmail.com'
  };


  constructor() { }


  guardar( miFormulario: NgForm) {
    console.log('Submit');
    console.log( miFormulario );
    console.log ( this.alumno);
  }

}
