import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';



@Component({
  selector: 'app-formulario-codigo',
  templateUrl: './formulario-codigo.component.html',
  styles: []
})
export class FormularioCodigoComponent  {


  formulario: FormGroup;


  alumno = {
    nombre: 'Richard',
    apellidos: 'Gere',
    correo: 'rgere@gmail.com'
  };


  constructor() {

    this.formulario = new FormGroup({
      'nombre': new FormControl('', [
        Validators.required,
        Validators.minLength(3),
        this.noAlumnoPedro
      ]),
      'apellidos': new FormControl('', Validators.required),
      'correo': new FormControl('', [
        Validators.required,
        Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$'),
       ],
       this.existeCorreo)
    });

    this.formulario.setValue(this.alumno);

  }


  guardar() {
    console.log ( 'Submit ');
    console.log ( this.formulario.value );
    console.log ( this.formulario.valid );
    console.log ( this.formulario );

    // Reseteamos el formulario
    // Se queda limpio, y sin tocar

    // this.formulario.reset();


  }

  // Validador que devuelve un par de valores

  noAlumnoPedro ( control: FormControl ): { [s: string ]: boolean } {

    if ( control.value === 'Pedro') {
      return {
        nopedro: true
      };
    }
      return null;
  }

  existeCorreo( control: FormControl ) : Promise<any> {

    return  new Promise( (resolve, reject ) => {

      setTimeout( () => {
         if ( control.value === 'carlos@gmail.com') {
           resolve( {
             existe: true
            } );
         } else {
           resolve ( null );
         }
      }, 3000);
    } ) ;

  }


}
