export class Alumno {
    id: number;
    nombre: string;
    apellidos: string;
    email: string;
}
