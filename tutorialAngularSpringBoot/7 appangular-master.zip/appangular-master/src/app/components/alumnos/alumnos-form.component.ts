import { Component, OnInit } from '@angular/core';
import { Alumno } from './alumno';
import swal from 'sweetalert';
import { AlumnoService } from '../../services/alumno.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-alumnos-form',
  templateUrl: './alumnos-form.component.html',
  styleUrls: ['./alumnos-form.component.css']
})
export class AlumnosFormComponent implements OnInit {

  titulo = 'Alumnos';

  alumno: Alumno = new Alumno();

  constructor(
    private alumnoService: AlumnoService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.editarAlumno();
  }

  guardarAlumno() {
    this.alumnoService.creaAlumno ( this.alumno )
    .subscribe ( data => {
      console.log(data);
      this.router.navigate(['/alumnos']);
      swal(
        'Guardado',
        `El alumno ${this.alumno.nombre} ha sido guardado`,
        'success'
      );
    });

  }

  editarAlumno() {
    this.activatedRoute.params.subscribe( params => {
      const id = params['id'];
      if ( id ) {
        this.alumnoService.getAlumno(id).subscribe ( (data: Alumno) => {
          this.alumno = data;
          console.log(this.alumno);
        });
      }
    });
  }

  actualizarAlumno() {
    this.alumnoService.updateAlumno( this.alumno )
    .subscribe( (data: Alumno) => {
      this.router.navigate(['/alumnos']);
      swal(
        'Actualizado',
        `El alumno ${data.nombre} ha sido actualizado`,
        'success'
      );
    });
  }

}
