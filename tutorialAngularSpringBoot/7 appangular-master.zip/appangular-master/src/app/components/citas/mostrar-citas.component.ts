import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CitasService } from '../../services/citas.service';
import { Cita } from 'src/app/models/cita';

@Component({
  selector: 'app-mostrar-citas',
  templateUrl: './mostrar-citas.component.html',
  styles: []
})
export class MostrarCitasComponent implements OnInit {


  citas: Cita[] = [];
  terminoDeBusqueda: string;

  constructor(private activatedRoute: ActivatedRoute,
              private citasService: CitasService) {}

  ngOnInit() {
    this.activatedRoute.params.subscribe( params => {
      this.citas = this.citasService.buscarCitas( params['termino']);
      this.terminoDeBusqueda = params['termino'];
      console.log(this.citas);
    });
  }

}
