import { Component, OnInit } from '@angular/core';
import { CitasService } from '../../services/citas.service';
import { Cita } from 'src/app/models/cita';
import { Router } from '@angular/router';

@Component({
  selector: 'app-citas',
  templateUrl: './citas.component.html',
  styleUrls: ['./citas.component.css']
})
export class CitasComponent implements OnInit {

  citas: Cita[];

  constructor(private citasService: CitasService,
              private router: Router) {
    this.citas = citasService.getCitas();
  }

  ngOnInit() {
  }

  verCita(id: number) {
    this.router.navigate(['/cita', id]);
  }
}
