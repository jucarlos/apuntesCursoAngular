import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styles: []
})
export class PipesComponent implements OnInit {

  ciudad = 'Toledo';
  primos = [1, 2, 3, 5, 7, 11, 13];
  cambio = 166.386789;
  porcentaje = 0.75;
  porcentaje2 = 0.4587;
  precio = 1533.56;

  alumno = {
    nombre: 'Angelina',
    apellidos: 'Jolie',
    edad: 45
  };


  promesa = new Promise ( (resolve, reject ) => {

    setTimeout ( () => {
      resolve( 'Terminó !!!');
    }, 4000);

  });

  fecha = new Date();

  cadenaDeTexto = 'Saber que se sabe lo que se sabe y que no se sabe lo que no se sabe; he aquí el verdadero saber. (Confucio)';


  constructor() { }

  ngOnInit() {
  }

}
