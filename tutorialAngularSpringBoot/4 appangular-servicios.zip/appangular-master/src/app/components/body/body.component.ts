import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {

  cita: any = {
    mensaje: 'No pienso nunca en el futuro porque llega muy pronto.',
    autor: 'Albert Einstein'
  };

  textoDelBoton = 'Ocultar Cita';

  citaVisible = true;


  autores: string[] = ['Aristóteles', 'Einstein', 'San Agustín', 'Platón'];


  constructor() { }

  ngOnInit() {
  }

  ocultaMuestraCita() {
    this.citaVisible = !this.citaVisible;

    if ( this.citaVisible ) {
      this.textoDelBoton = 'Ocultar Cita';
    } else {
      this.textoDelBoton = 'Mostrar Cita';
    }
  }

}
