export class Cita {
    id: number;
    autor: string;
    frase: string;
    img?: string;
}
