import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Alumno } from '../components/alumnos/alumno';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AlumnoService {

  private urlEndPoint = 'http://localhost:8080/api/alumnos';

  private httpHeaders = new HttpHeaders({'Content-Type': 'application/json'});


  constructor(private http: HttpClient, private router: Router) { }

  getAlumnos() {
    return this.http.get( this.urlEndPoint);
  }

  creaAlumno( alumno: Alumno ) {
    return this.http.post(this.urlEndPoint, alumno, { headers: this.httpHeaders})
    .pipe(
      catchError ( e => {
          console.log(e);
          Swal.fire(
            'Error al guardar',
            e.error.mensaje,
            'error'
          );
          return throwError ( e );

      })
    );
  }

  getAlumno ( id: number ) {
    return this.http.get( `${this.urlEndPoint}/${id}`)
    .pipe( catchError ( e => {
      this.router.navigate(['/alumnos']);
     // console.log(e);
      Swal.fire(
        'Error al editar',
        e.error.mensaje,
        'error'
      );
      return throwError ( e );
      }
      ));
  }

  updateAlumno( alumno: Alumno ) {
    return this.http.put(`${this.urlEndPoint}/${alumno.id}`, alumno, {headers: this.httpHeaders})
    .pipe(
      catchError ( e => {
          console.log(e);
          Swal.fire(
            'Error al editar',
            e.error.mensaje,
            'error'
          );
          return throwError ( e );

      })
    );
  }

  deleteAlumno ( id: number ) {
    return this.http.delete ( `${this.urlEndPoint}/${id}`);
  }

}
