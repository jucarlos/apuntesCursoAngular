import { Component, OnInit } from '@angular/core';
import { Alumno } from './alumno';
import swal from 'sweetalert';
import { AlumnoService } from '../../services/alumno.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-alumnos-form',
  templateUrl: './alumnos-form.component.html',
  styleUrls: ['./alumnos-form.component.css']
})
export class AlumnosFormComponent implements OnInit {

  titulo = 'Alumnos';

  guardando = false;

  alumno: Alumno = new Alumno();

  constructor(
    private alumnoService: AlumnoService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.editarAlumno();
  }

  guardarAlumno() {
    this.guardando = true;
    this.alumnoService.creaAlumno ( this.alumno )
    .subscribe ( data => {
      this.guardando = false;
      console.log(data);
      this.router.navigate(['/alumnos']);
      swal(
        'Guardado',
        `El alumno ${this.alumno.nombre} ha sido guardado`,
        'success'
      );
    });

  }

  editarAlumno() {
    this.activatedRoute.params.subscribe( params => {
      const id = params['id'];
      if ( id ) {
        this.alumnoService.getAlumno(id)
        .subscribe ( (data: any) => {
          this.alumno = data.alumno;
          console.log( data );
        });
      }
    });
  }

  actualizarAlumno() {
    this.guardando = true;
    this.alumnoService.updateAlumno( this.alumno )
    .subscribe( (data: Alumno) => {
      this.guardando = false;
      this.router.navigate(['/alumnos']);
      swal(
        'Actualizado',
        `El alumno ${data.nombre} ha sido actualizado`,
        'success'
      );
    });
  }


}
