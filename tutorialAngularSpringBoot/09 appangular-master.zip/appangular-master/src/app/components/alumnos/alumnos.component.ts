import { Component, OnInit } from '@angular/core';
import { Alumno } from './alumno';
import { AlumnoService } from '../../services/alumno.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-alumnos',
  templateUrl: './alumnos.component.html',
  styleUrls: ['./alumnos.component.css']
})
export class AlumnosComponent implements OnInit {

//  alumnos: Alumno[] = [];
  alumnos: any;

  constructor(private alumnoService: AlumnoService) { }

  ngOnInit() {
    // this.alumnoService.getAlumnos()
    // .subscribe ( (data: Alumno[]) => {
    //   this.alumnos = data;
    //   console.log(this.alumnos);
    // });

    this.alumnos = this.alumnoService.getAlumnos();


  }

  borrarAlumno( alumno: Alumno ) {
    Swal.fire({
      title: 'Estás seguro',
      text: `Se va a proceder a borrar a ${alumno.nombre} `,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Sí, bórralo'
    }).then((result) => {
      if (result.value) {
        this.alumnoService.deleteAlumno( alumno.id )
        .subscribe ( data => {
          this.alumnos = this.alumnoService.getAlumnos();
          Swal.fire(
            'Borrado!',
            'El alumno ha sido borrado.',
            'success'
          );

        });
      }
    });


  }

}
