export class Alumno {
    id: number;
    nombre: string;
    apellidos: string;
    numescolar: string;
    email: string;
}
