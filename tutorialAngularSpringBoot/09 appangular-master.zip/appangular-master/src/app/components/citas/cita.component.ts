import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CitasService } from 'src/app/services/citas.service';
import { Cita } from 'src/app/models/cita';

@Component({
  selector: 'app-cita',
  templateUrl: './cita.component.html',
  styles: []
})
export class CitaComponent implements OnInit {

  idCita: number;
  cita: Cita;

  constructor(private activatedRoute: ActivatedRoute,
              private citasService: CitasService ) {

    this.activatedRoute.params.subscribe ( data => {
      this.cita = this.citasService.getCita( data.id );

      console.log(this.cita);
    });
   }

  ngOnInit() {
  }

}
