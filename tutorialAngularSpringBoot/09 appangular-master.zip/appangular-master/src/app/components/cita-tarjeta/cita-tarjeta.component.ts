import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Cita } from 'src/app/models/cita';
import { Router } from '@angular/router';


@Component({
  selector: 'app-cita-tarjeta',
  templateUrl: './cita-tarjeta.component.html',
  styles: []
})
export class CitaTarjetaComponent implements OnInit {

  @Input() cita: Cita  ;
  @Output() citaSeleccionada: EventEmitter<number>;

  constructor(private router: Router) {
    this.citaSeleccionada = new EventEmitter();
   }

  ngOnInit() {
  }

  verCita(id: number) {
   this.citaSeleccionada.emit( this.cita.id);
  }
}

